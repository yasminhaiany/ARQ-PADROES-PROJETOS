
public class WinButton implements Button {
	
	public void paint() {
		System.out.println("Winbutton.");
	}

}
