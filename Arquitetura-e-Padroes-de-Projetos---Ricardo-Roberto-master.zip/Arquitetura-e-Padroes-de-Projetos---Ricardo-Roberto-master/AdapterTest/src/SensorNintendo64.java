
public class SensorNintendo64 {
	
	public void conectarNintendo64() {
		System.out.println("Um novo controle foi conectado ao sensor do Nintendo64.");
	}

}
