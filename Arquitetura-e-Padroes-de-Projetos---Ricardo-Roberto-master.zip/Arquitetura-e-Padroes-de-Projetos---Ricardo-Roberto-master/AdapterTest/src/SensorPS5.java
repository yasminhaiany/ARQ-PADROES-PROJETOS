
public class SensorPS5 {
	
	public void conectarPS5() {
		System.out.println("Um novo controle foi conectado ao sensor do PS5.");
	}

}
