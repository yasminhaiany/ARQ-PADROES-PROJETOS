
public class SensorXbox2 {
	
	public void conectarXbox2() {
		System.out.println("Um novo controle foi conectado ao sensor do Xbox.");
	}

}
