
public class HardDrive {
	
	public byte[] read(long lba, int size) {
		System.out.println("Harddrive.");
		return null;
	}

}
