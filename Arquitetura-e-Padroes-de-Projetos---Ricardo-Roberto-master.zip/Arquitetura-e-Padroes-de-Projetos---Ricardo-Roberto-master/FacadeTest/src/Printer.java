
public class Printer {
	
	public void startPool() {
		System.out.println("Inicializando fila de impressão.");
	}

}
