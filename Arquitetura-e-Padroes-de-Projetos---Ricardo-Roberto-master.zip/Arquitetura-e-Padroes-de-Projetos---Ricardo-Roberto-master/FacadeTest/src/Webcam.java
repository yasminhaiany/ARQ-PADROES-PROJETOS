
public class Webcam {
	
	public void startConnection() {
		System.out.println("Inicializando conexão com a webcam.");
		 
	}

}
