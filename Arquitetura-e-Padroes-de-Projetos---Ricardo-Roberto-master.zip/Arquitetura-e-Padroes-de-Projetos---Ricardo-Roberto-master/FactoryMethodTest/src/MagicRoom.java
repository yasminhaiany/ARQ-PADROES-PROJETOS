
public class MagicRoom extends Room {

	void connect(Room room) {
		System.out.println("Connected MagicRoom.");
	}
	

}
