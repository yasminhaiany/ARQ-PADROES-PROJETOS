
public class Main {

	public static void main(String[] args) {
		
		MazeGame ordinarygame = new OrdinaryMazeGame();
		MazeGame magicgame = new MagicMazeGame();
		
	}

}
