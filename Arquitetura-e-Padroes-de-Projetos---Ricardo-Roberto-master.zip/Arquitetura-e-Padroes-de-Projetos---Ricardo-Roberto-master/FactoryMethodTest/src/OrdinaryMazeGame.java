
public class OrdinaryMazeGame extends MazeGame {
	
	protected Room makeroom() {
		return new OrdinaryRoom();
	}

}
