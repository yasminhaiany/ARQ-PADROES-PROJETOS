
public class OrdinaryRoom extends Room {
	
	void connect(Room room) {
		System.out.println("Connected OrdinaryRoom.");
	}

}
