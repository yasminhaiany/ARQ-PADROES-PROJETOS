
public abstract class Room {

	abstract void connect(Room room);
}